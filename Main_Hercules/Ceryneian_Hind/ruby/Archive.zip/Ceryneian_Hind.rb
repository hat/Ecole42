# require "oauth2"
# UID = "1f117c968b63eab7dca2cc7d40b8291ec2f957dafea9a3bf68c4e021ffab92be"
# SECRET = "01811c0418688145ed48d5cac69c4046efe7cd9f0dc61de713e53c3b60cc64ed"
# # Create the client with your credentials
# client = OAuth2::Client.new(UID, SECRET, site: "https://api.intra.42.fr")
# # Get an access token
# token = client.client_credentials.get_token
# token.get("/v2/cursus").parsed
# # => [{"id"=>1, "created_at"=>"2014-11-02T17:43:38.480+01:00", "name"=>"42", "slug"=>"42", "users_count"=>1918, "users_url"=>"https://api.intra.42.fr/v2/cursus/42/users", "projects_url"=>"https://api.intra.42.fr/v2/cursus/42/projects", "topics_url"=>"https://api.intra.42.fr/v2/cursus/42/topics"}, ...]
# users_in_cursus = token.get("/v2/cursus/42/users").parsed
# # => {"id"=>2, "login"=>"avisenti", "url"=>"https://api.intra.42.fr/v2/users/avisenti", "end_at"=>nil}, {"id"=>3, "login"=>"spariaud", "url"=>"https://api.intra.42.fr/v2/users/spariaud", "end_at"=>nil}, ...
# users_in_cursus.count
# # => 30
# puts second_page = token.get("/v2/cursus/42/users", params: {page: {number: 2}})
# # => #<OAuth2::Response:0x007f9ba3b7eb98 @response=#<Faraday::Response:0x007f9ba3b949c0 @on_complete_callbacks=[], @env=#<Faraday::Env @method=:get @body="[{\"id\":35,\"login\":\"droger\",\"url\":\"https://api.intra.42.fr/v2/users/droger\",\"end_at\":null},{\"id\":36,\"login\":\"edelbe\",\"url\":\"https://api.intra.42.fr/v2/users/edelbe\"...
# puts second_page.parsed.count
# second_page.parsed
# # => {"id"=>35, "login"=>"droger", "url"=>"https://api.intra.42.fr/v2/users/droger", "end_at"=>nil}, {"id"=>36, "login"=>"edelbe", "url"=>"https://api.intra.42.fr/v2/users/edelbe", "end_at"=>nil}, ...
# second_page.headers["Link"]
# # => "<https://api.intra.42.fr/v2/cursus/42/users?page=3>; rel=\"next\", <https://api.intra.42.fr/v2/cursus/42/users?page=1>; rel=\"prev\", <https://api.intra.42.fr/v2/cursus/42/users?page=1>; rel=\"first\", <https://api.intra.42.fr/v2/cursus/42/users?page=64>; rel=\"last\""

require 'fortytwo'

YOUR_API_KEY = "1f117c968b63eab7dca2cc7d40b8291ec2f957dafea9a3bf68c4e021ffab92be"
YOUR_API_SECRET = "01811c0418688145ed48d5cac69c4046efe7cd9f0dc61de713e53c3b60cc64ed"

client = FortyTwo::Client.new({ api_key: YOUR_API_KEY, api_secret: YOUR_API_SECRET })

response = client.user("thendric")
user     = response.user

f = File.open(ARGV[0], "r")
f.each_line do |line|
 	response = client.user(line)
	user     = response.user

	if user.location
		puts user.location
	else
		puts "User not logged in"
	end
end
f.close


response = client.user("hkunduru")
user     = response.user

user.cursus_users.each do |user_cursus|
  puts user_cursus.id                   #=> 14121
  user_cursus.begin_at             #=> "2016-09-19T22:00:00.000Z"
  user_cursus.end_at               #=> nil
  user_cursus.grade                #=> "Midshipman"
  puts user_cursus.level                #=> 3.91
  user_cursus.cursus_id            #=> 1
  puts user.login

  user_cursus.skills.each do |skill|
    skill.id                       #=> 3
    skill.name                     #=> "Rigor"
    skill.level                    #=> 2.88
  end

  user_cursus.cursus.id            #=> 1
  user_cursus.cursus.created_at    #=> "2014-11-02T16:43:38.480Z"
  user_cursus.cursus.name          #=> "42"
  user_cursus.cursus.slug          #=> "42"
end